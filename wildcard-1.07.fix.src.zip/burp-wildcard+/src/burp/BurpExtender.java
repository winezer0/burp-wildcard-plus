package burp;

import hvqzao.wildcard.WildcardExtension;

public class BurpExtender extends WildcardExtension {
    // see hvqzao.flow.FlowExtension
}
